[paste the Python code above]
